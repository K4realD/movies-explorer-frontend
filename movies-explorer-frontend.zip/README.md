# movies-explorer-frontend
##Фронтенд для проекта Movies
Многостраничный сайт, представляющий собой поисковик фильмов с регистрацией пользователя.

##Стек технологий
HTML, CSS, JavaScript, React.js, Wedpack, БЭМ

ссылка на макет: https://disk.yandex.ru/d/77H0UQjeUzd14Q
ссылка на сайт: https://movies-k4d.nomoredomains.icu
ссылка на пул реквест: https://github.com/K4realD/movies-explorer-frontend/pull/2